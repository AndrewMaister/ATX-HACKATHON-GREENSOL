use crate::{
    // deprecated_processor::{
    //     process_deprecated_create_master_edition, process_deprecated_create_reservation_list,
    //     process_deprecated_mint_new_edition_from_master_edition_via_printing_token,
    //     process_deprecated_mint_printing_tokens, process_deprecated_mint_printing_tokens_via_token,
    //     process_deprecated_set_reservation_list,
    // },
    error::MetadataError,
    instruction::MetadataInstruction,
    state::{
        Data, Key, MasterEditionV1, MasterEditionV2, Metadata, EDITION, MAX_MASTER_EDITION_LEN,
        PREFIX,
        WHITE_PREFIX,
        AuctionSale,
        TOKEN_PUBKEY,
        NATIVE_TOKEN_PUBKEY,
        WHITE_LIST_LENGTH,
        PROGRAM_ADMIN_PUBKEY,
        RECEIVE_PUBKEY,
        RATE_PREFIX,
        RATE_LENGTH,
        Rate,
        WhitelistedCreator,
        METAPLEX_PROGRAM_ID,
    },
    utils::{
        assert_data_valid, assert_derivation, assert_initialized,
        assert_mint_authority_matches_mint, assert_owned_by, assert_signer,
        assert_token_program_matches_package, assert_update_authority_is_correct,
        create_or_allocate_account_raw, get_owner_from_token_account,
        process_create_metadata_accounts_logic,
        process_mint_new_edition_from_master_edition_via_token_logic, puff_out_data_fields,
        transfer_mint_authority, CreateMetadataAccountsLogicArgs,
        MintNewEditionFromMasterEditionViaTokenLogicArgs,
    },
};
// use arrayref::array_ref;
use borsh::{BorshDeserialize, BorshSerialize};
// use metaplex_token_vault::{error::VaultError, state::VaultState};
use solana_program::{
    account_info::{next_account_info, AccountInfo},
    entrypoint::ProgramResult,
    msg,
    program_error::ProgramError,
    pubkey::Pubkey,
    program::{invoke, invoke_signed},
    sysvar::{rent::Rent, Sysvar},
    program_pack::{ Pack},
    system_instruction,
    instruction::{AccountMeta},
};
use spl_token::state::{Account as TokenAccount, Mint};
use std::str::FromStr;
use spl_associated_token_account::{get_associated_token_address};
pub fn process_instruction<'a>(
    program_id: &'a Pubkey,
    accounts: &'a [AccountInfo<'a>],
    input: &[u8],
) -> ProgramResult {
    msg!("process begin");
    let instruction = MetadataInstruction::try_from_slice(input)?;
    msg!("parse instruction end");
    match instruction {
        MetadataInstruction::CreateMetadataAccount(args) => {
            msg!("Instruction: Create Metadata Accounts");
            process_create_metadata_accounts(
                program_id,
                accounts,
                args.data,
                false,
                args.is_mutable,
            )
        }
        MetadataInstruction::UpdateMetadataAccount(args) => {
            msg!("Instruction: Update Metadata Accounts");
            process_update_metadata_accounts(
                program_id,
                accounts,
                args.data,
                args.update_authority,
                args.primary_sale_happened,
            )
        }
        // MetadataInstruction::DeprecatedCreateMasterEdition(args) => {
        //     msg!("Instruction: Deprecated Create Master Edition");
        //     process_deprecated_create_master_edition(program_id, accounts, args.max_supply)
        // }
        // MetadataInstruction::DeprecatedMintNewEditionFromMasterEditionViaPrintingToken => {
        //     msg!("Instruction: Deprecated Mint New Edition from Master Edition Via Token");
        //     process_deprecated_mint_new_edition_from_master_edition_via_printing_token(
        //         program_id, accounts,
        //     )
        // }
        MetadataInstruction::UpdatePrimarySaleHappenedViaToken => {
            msg!("Instruction: Update primary sale via token");
            process_update_primary_sale_happened_via_token(program_id, accounts)
        }
        // MetadataInstruction::DeprecatedSetReservationList(args) => {
        //     msg!("Instruction: Deprecated Set Reservation List");
        //     process_deprecated_set_reservation_list(
        //         program_id,
        //         accounts,
        //         args.reservations,
        //         args.total_reservation_spots,
        //         args.offset,
        //         args.total_spot_offset,
        //     )
        // }
        // MetadataInstruction::DeprecatedCreateReservationList => {
        //     msg!("Instruction: Deprecated Create Reservation List");
        //     process_deprecated_create_reservation_list(program_id, accounts)
        // }
        MetadataInstruction::SignMetadata => {
            msg!("Instruction: Sign Metadata");
            process_sign_metadata(program_id, accounts)
        }
        // MetadataInstruction::DeprecatedMintPrintingTokensViaToken(args) => {
        //     msg!("Instruction: Deprecated Mint Printing Tokens Via Token");
        //     process_deprecated_mint_printing_tokens_via_token(program_id, accounts, args.supply)
        // }
        // MetadataInstruction::DeprecatedMintPrintingTokens(args) => {
        //     msg!("Instruction: Deprecated Mint Printing Tokens");
        //     process_deprecated_mint_printing_tokens(program_id, accounts, args.supply)
        // }
        MetadataInstruction::CreateMasterEdition(args) => {
            msg!("Instruction: Create Master Edition");
            process_create_master_edition(program_id, accounts, args.max_supply)
        }
        MetadataInstruction::MintNewEditionFromMasterEditionViaToken(args) => {
            msg!("Instruction: Mint New Edition from Master Edition Via Token");
            process_mint_new_edition_from_master_edition_via_token(
                program_id,
                accounts,
                args.edition,
                false,
            )
        }
        MetadataInstruction::ConvertMasterEditionV1ToV2 => {
            msg!("Instruction: Convert Master Edition V1 to V2");
            process_convert_master_edition_v1_to_v2(program_id, accounts)
        }
        MetadataInstruction::MintNewEditionFromMasterEditionViaVaultProxy(args) => {
            msg!("Instruction: Mint New Edition from Master Edition Via Vault Proxy");
            process_mint_new_edition_from_master_edition_via_vault_proxy(
                program_id,
                accounts,
                args.edition,
            )
        }
        MetadataInstruction::PuffMetadata => {
            msg!("Instruction: Puff Metadata");
            process_puff_metadata_account(program_id, accounts)
        }
        MetadataInstruction::CreateAuctionSale(args)=>{
            msg!("Instruction:  CreateAuctionSale");
            process_auction_sale(
                program_id,
                accounts,
                args.price,
                args.trade_type,
                args.trade_key,
                // args.creator_num,   
                     )
        }
        MetadataInstruction::CreateAuctionBuy(args)=>{
            process_auction_buy(accounts,program_id)
        }
        MetadataInstruction::CreateAuctionCancel=>{
            process_auction_cancel(accounts,program_id)
        }
        MetadataInstruction::WhitelistedCreator(args)=>{
            process_add_whiteList(program_id,accounts,args.activated)
        }
        MetadataInstruction::Rate(args)=>{
            process_change_rate(program_id,accounts,args.rate,args.creator_soc,args.creator_sol)
        }
    }
}

pub fn process_create_metadata_accounts<'a>(
    program_id: &'a Pubkey,
    accounts: &'a [AccountInfo<'a>],
    data: Data,
    allow_direct_creator_writes: bool,
    is_mutable: bool,
) -> ProgramResult {
    // 
    Ok(())
}

/// Update existing account instruction
pub fn process_update_metadata_accounts(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    optional_data: Option<Data>,
    update_authority: Option<Pubkey>,
    primary_sale_happened: Option<bool>,
) -> ProgramResult {
    // let account_info_iter = &mut accounts.iter();

    // let metadata_account_info = next_account_info(account_info_iter)?;
    // let update_authority_info = next_account_info(account_info_iter)?;
    // let mut metadata = Metadata::from_account_info(metadata_account_info)?;

    // assert_owned_by(metadata_account_info, program_id)?;
    // assert_update_authority_is_correct(&metadata, update_authority_info)?;

    // if let Some(data) = optional_data {
    //     if metadata.is_mutable {
    //         assert_data_valid(
    //             &data,
    //             update_authority_info.key,
    //             &metadata,
    //             false,
    //             update_authority_info.is_signer,
    //             true,
    //         )?;
    //         metadata.data = data;
    //     } else {
    //         return Err(MetadataError::DataIsImmutable.into());
    //     }
    // }

    // if let Some(val) = update_authority {
    //     metadata.update_authority = val;
    // }

    // if let Some(val) = primary_sale_happened {
    //     if val {
    //         metadata.primary_sale_happened = val
    //     } else {
    //         return Err(MetadataError::PrimarySaleCanOnlyBeFlippedToTrue.into());
    //     }
    // }

    // puff_out_data_fields(&mut metadata);

    // metadata.serialize(&mut *metadata_account_info.data.borrow_mut())?;
    Ok(())
}

pub fn process_update_primary_sale_happened_via_token(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
) -> ProgramResult {
    // let account_info_iter = &mut accounts.iter();

    // let metadata_account_info = next_account_info(account_info_iter)?;
    // let owner_info = next_account_info(account_info_iter)?;
    // let token_account_info = next_account_info(account_info_iter)?;

    // let token_account: TokenAccount = assert_initialized(token_account_info)?;
    // let mut metadata = Metadata::from_account_info(metadata_account_info)?;

    // assert_owned_by(metadata_account_info, program_id)?;
    // assert_owned_by(token_account_info, &spl_token::id())?;

    // if !owner_info.is_signer {
    //     return Err(ProgramError::MissingRequiredSignature);
    // }

    // if token_account.owner != *owner_info.key {
    //     return Err(MetadataError::OwnerMismatch.into());
    // }

    // if token_account.amount == 0 {
    //     return Err(MetadataError::NoBalanceInAccountForAuthorization.into());
    // }

    // if token_account.mint != metadata.mint {
    //     return Err(MetadataError::MintMismatch.into());
    // }

    // metadata.primary_sale_happened = true;
    // metadata.serialize(&mut *metadata_account_info.data.borrow_mut())?;

    Ok(())
}

pub fn process_sign_metadata(program_id: &Pubkey, accounts: &[AccountInfo]) -> ProgramResult {
    // let account_info_iter = &mut accounts.iter();

    // let metadata_info = next_account_info(account_info_iter)?;
    // let creator_info = next_account_info(account_info_iter)?;

    // assert_signer(creator_info)?;
    // assert_owned_by(metadata_info, program_id)?;

    // let mut metadata = Metadata::from_account_info(metadata_info)?;

    // if let Some(creators) = &mut metadata.data.creators {
    //     let mut found = false;
    //     for creator in creators {
    //         if creator.address == *creator_info.key {
    //             creator.verified = true;
    //             found = true;
    //             break;
    //         }
    //     }
    //     if !found {
    //         return Err(MetadataError::CreatorNotFound.into());
    //     }
    // } else {
    //     return Err(MetadataError::NoCreatorsPresentOnMetadata.into());
    // }
    // metadata.serialize(&mut *metadata_info.data.borrow_mut())?;

    Ok(())
}

/// Create master edition
pub fn process_create_master_edition(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    max_supply: Option<u64>,
) -> ProgramResult {
    // let account_info_iter = &mut accounts.iter();

    // let edition_account_info = next_account_info(account_info_iter)?;
    // let mint_info = next_account_info(account_info_iter)?;
    // let update_authority_info = next_account_info(account_info_iter)?;
    // let mint_authority_info = next_account_info(account_info_iter)?;
    // let payer_account_info = next_account_info(account_info_iter)?;
    // let metadata_account_info = next_account_info(account_info_iter)?;
    // let token_program_info = next_account_info(account_info_iter)?;
    // let system_account_info = next_account_info(account_info_iter)?;
    // let rent_info = next_account_info(account_info_iter)?;

    // let metadata = Metadata::from_account_info(metadata_account_info)?;
    // let mint: Mint = assert_initialized(mint_info)?;

    // let bump_seed = assert_derivation(
    //     program_id,
    //     edition_account_info,
    //     &[
    //         PREFIX.as_bytes(),
    //         program_id.as_ref(),
    //         &mint_info.key.as_ref(),
    //         EDITION.as_bytes(),
    //     ],
    // )?;

    // assert_token_program_matches_package(token_program_info)?;
    // assert_mint_authority_matches_mint(&mint.mint_authority, mint_authority_info)?;
    // assert_owned_by(metadata_account_info, program_id)?;
    // assert_owned_by(mint_info, &spl_token::id())?;

    // if metadata.mint != *mint_info.key {
    //     return Err(MetadataError::MintMismatch.into());
    // }

    // if mint.decimals != 0 {
    //     return Err(MetadataError::EditionMintDecimalsShouldBeZero.into());
    // }

    // assert_update_authority_is_correct(&metadata, update_authority_info)?;

    // if mint.supply != 1 {
    //     return Err(MetadataError::EditionsMustHaveExactlyOneToken.into());
    // }

    // let edition_authority_seeds = &[
    //     PREFIX.as_bytes(),
    //     program_id.as_ref(),
    //     &mint_info.key.as_ref(),
    //     EDITION.as_bytes(),
    //     &[bump_seed],
    // ];

    // create_or_allocate_account_raw(
    //     *program_id,
    //     edition_account_info,
    //     rent_info,
    //     system_account_info,
    //     payer_account_info,
    //     MAX_MASTER_EDITION_LEN,
    //     edition_authority_seeds,
    // )?;

    // let mut edition = MasterEditionV2::from_account_info(edition_account_info)?;

    // edition.key = Key::MasterEditionV2;
    // edition.supply = 0;
    // edition.max_supply = max_supply;
    // edition.serialize(&mut *edition_account_info.data.borrow_mut())?;

    // // While you can't mint any more of your master record, you can
    // // mint as many limited editions as you like within your max supply.
    // transfer_mint_authority(
    //     edition_account_info.key,
    //     edition_account_info,
    //     mint_info,
    //     mint_authority_info,
    //     token_program_info,
    // )?;

    Ok(())
}

pub fn process_mint_new_edition_from_master_edition_via_token<'a>(
    program_id: &'a Pubkey,
    accounts: &'a [AccountInfo<'a>],
    edition: u64,
    ignore_owner_signer: bool,
) -> ProgramResult {
    // let account_info_iter = &mut accounts.iter();

    // let new_metadata_account_info = next_account_info(account_info_iter)?;
    // let new_edition_account_info = next_account_info(account_info_iter)?;
    // let master_edition_account_info = next_account_info(account_info_iter)?;
    // let mint_info = next_account_info(account_info_iter)?;
    // let edition_marker_info = next_account_info(account_info_iter)?;
    // let mint_authority_info = next_account_info(account_info_iter)?;
    // let payer_account_info = next_account_info(account_info_iter)?;
    // let owner_account_info = next_account_info(account_info_iter)?;
    // let token_account_info = next_account_info(account_info_iter)?;
    // let update_authority_info = next_account_info(account_info_iter)?;
    // let master_metadata_account_info = next_account_info(account_info_iter)?;
    // let token_program_account_info = next_account_info(account_info_iter)?;
    // let system_account_info = next_account_info(account_info_iter)?;
    // let rent_info = next_account_info(account_info_iter)?;

    // process_mint_new_edition_from_master_edition_via_token_logic(
    //     &program_id,
    //     MintNewEditionFromMasterEditionViaTokenLogicArgs {
    //         new_metadata_account_info,
    //         new_edition_account_info,
    //         master_edition_account_info,
    //         mint_info,
    //         edition_marker_info,
    //         mint_authority_info,
    //         payer_account_info,
    //         owner_account_info,
    //         token_account_info,
    //         update_authority_info,
    //         master_metadata_account_info,
    //         token_program_account_info,
    //         system_account_info,
    //         rent_info,
    //     },
    //     edition,
    //     ignore_owner_signer,
    // )
    Ok(())
}

pub fn process_convert_master_edition_v1_to_v2(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
) -> ProgramResult {
    // let account_info_iter = &mut accounts.iter();
    // let master_edition_info = next_account_info(account_info_iter)?;
    // let one_time_printing_auth_mint_info = next_account_info(account_info_iter)?;
    // let printing_mint_info = next_account_info(account_info_iter)?;

    // assert_owned_by(master_edition_info, program_id)?;
    // assert_owned_by(one_time_printing_auth_mint_info, &spl_token::id())?;
    // assert_owned_by(printing_mint_info, &spl_token::id())?;
    // let master_edition: MasterEditionV1 = MasterEditionV1::from_account_info(master_edition_info)?;
    // let printing_mint: Mint = assert_initialized(printing_mint_info)?;
    // let auth_mint: Mint = assert_initialized(one_time_printing_auth_mint_info)?;
    // if master_edition.one_time_printing_authorization_mint != *one_time_printing_auth_mint_info.key
    // {
    //     return Err(MetadataError::OneTimePrintingAuthMintMismatch.into());
    // }

    // if master_edition.printing_mint != *printing_mint_info.key {
    //     return Err(MetadataError::PrintingMintMismatch.into());
    // }

    // if printing_mint.supply != 0 {
    //     return Err(MetadataError::PrintingMintSupplyMustBeZeroForConversion.into());
    // }

    // if auth_mint.supply != 0 {
    //     return Err(MetadataError::OneTimeAuthMintSupplyMustBeZeroForConversion.into());
    // }

    // MasterEditionV2 {
    //     key: Key::MasterEditionV2,
    //     supply: master_edition.supply,
    //     max_supply: master_edition.max_supply,
    // }
    // .serialize(&mut *master_edition_info.data.borrow_mut())?;

    Ok(())
}

pub fn process_mint_new_edition_from_master_edition_via_vault_proxy<'a>(
    program_id: &'a Pubkey,
    accounts: &'a [AccountInfo<'a>],
    edition: u64,
) -> ProgramResult {
    Ok(())
    // let account_info_iter = &mut accounts.iter();

    // let new_metadata_account_info = next_account_info(account_info_iter)?;
    // let new_edition_account_info = next_account_info(account_info_iter)?;
    // let master_edition_account_info = next_account_info(account_info_iter)?;
    // let mint_info = next_account_info(account_info_iter)?;
    // let edition_marker_info = next_account_info(account_info_iter)?;
    // let mint_authority_info = next_account_info(account_info_iter)?;
    // let payer_info = next_account_info(account_info_iter)?;
    // let vault_authority_info = next_account_info(account_info_iter)?;
    // let store_info = next_account_info(account_info_iter)?;
    // let safety_deposit_info = next_account_info(account_info_iter)?;
    // let vault_info = next_account_info(account_info_iter)?;
    // let update_authority_info = next_account_info(account_info_iter)?;
    // let master_metadata_account_info = next_account_info(account_info_iter)?;
    // let token_program_account_info = next_account_info(account_info_iter)?;
    // // we cant do much here to prove that this is the right token vault program except to prove that it matches
    // // the global one right now. We dont want to force people to use one vault program,
    // // so there is a bit of trust involved, but the attack vector here is someone provides
    // // an entirely fake vault program that claims to own token account X via it's pda but in order to spoof X's owner
    // // and get a free edition. However, we check that the owner of account X is the vault account's pda, so
    // // not sure how they would get away with it - they'd need to actually own that account! - J.
    // let token_vault_program_info = next_account_info(account_info_iter)?;
    // let system_account_info = next_account_info(account_info_iter)?;
    // let rent_info = next_account_info(account_info_iter)?;

    // let vault_data = vault_info.data.borrow();
    // let safety_deposit_data = safety_deposit_info.data.borrow();

    // // Since we're crunching out borsh for CPU units, do type checks this way
    // if vault_data[0] != metaplex_token_vault::state::Key::VaultV1 as u8 {
    //     return Err(VaultError::DataTypeMismatch.into());
    // }

    // if safety_deposit_data[0] != metaplex_token_vault::state::Key::SafetyDepositBoxV1 as u8 {
    //     return Err(VaultError::DataTypeMismatch.into());
    // }

    // // skip deserialization to keep things cheap on CPU
    // let token_program = Pubkey::new_from_array(*array_ref![vault_data, 1, 32]);
    // let vault_authority = Pubkey::new_from_array(*array_ref![vault_data, 65, 32]);
    // let store_on_sd = Pubkey::new_from_array(*array_ref![safety_deposit_data, 65, 32]);
    // let vault_on_sd = Pubkey::new_from_array(*array_ref![safety_deposit_data, 1, 32]);

    // let owner = get_owner_from_token_account(store_info)?;

    // let seeds = &[
    //     metaplex_token_vault::state::PREFIX.as_bytes(),
    //     token_vault_program_info.key.as_ref(),
    //     vault_info.key.as_ref(),
    // ];
    // let (authority, _) = Pubkey::find_program_address(seeds, token_vault_program_info.key);

    // if owner != authority {
    //     return Err(MetadataError::InvalidOwner.into());
    // }

    // assert_signer(vault_authority_info)?;

    // // Since most checks happen next level down in token program, we only need to verify
    // // that the vault authority signer matches what's expected on vault to authorize
    // // use of our pda authority, and that the token store is right for the safety deposit.
    // // Then pass it through.
    // assert_owned_by(vault_info, token_vault_program_info.key)?;
    // assert_owned_by(safety_deposit_info, token_vault_program_info.key)?;
    // assert_owned_by(store_info, token_program_account_info.key)?;

    // if &token_program != token_program_account_info.key {
    //     return Err(VaultError::TokenProgramProvidedDoesNotMatchVault.into());
    // }

    // if !vault_authority_info.is_signer {
    //     return Err(VaultError::AuthorityIsNotSigner.into());
    // }
    // if *vault_authority_info.key != vault_authority {
    //     return Err(VaultError::AuthorityDoesNotMatch.into());
    // }

    // if vault_data[195] != VaultState::Combined as u8 {
    //     return Err(VaultError::VaultShouldBeCombined.into());
    // }

    // if vault_on_sd != *vault_info.key {
    //     return Err(VaultError::SafetyDepositBoxVaultMismatch.into());
    // }

    // if *store_info.key != store_on_sd {
    //     return Err(VaultError::StoreDoesNotMatchSafetyDepositBox.into());
    // }

    // let args = MintNewEditionFromMasterEditionViaTokenLogicArgs {
    //     new_metadata_account_info,
    //     new_edition_account_info,
    //     master_edition_account_info,
    //     mint_info,
    //     edition_marker_info,
    //     mint_authority_info,
    //     payer_account_info: payer_info,
    //     owner_account_info: vault_authority_info,
    //     token_account_info: store_info,
    //     update_authority_info,
    //     master_metadata_account_info,
    //     token_program_account_info,
    //     system_account_info,
    //     rent_info,
    // };

    // process_mint_new_edition_from_master_edition_via_token_logic(program_id, args, edition, true)
}

/// Puff out the variable length fields to a fixed length on a metadata
/// account in a permissionless way.
pub fn process_puff_metadata_account(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
) -> ProgramResult {
    // let account_info_iter = &mut accounts.iter();

    // let metadata_account_info = next_account_info(account_info_iter)?;
    // let mut metadata = Metadata::from_account_info(metadata_account_info)?;

    // assert_owned_by(metadata_account_info, program_id)?;

    // puff_out_data_fields(&mut metadata);

    // let edition_seeds = &[
    //     PREFIX.as_bytes(),
    //     program_id.as_ref(),
    //     metadata.mint.as_ref(),
    //     EDITION.as_bytes(),
    // ];
    // let (_, edition_bump_seed) = Pubkey::find_program_address(edition_seeds, program_id);
    // metadata.edition_nonce = Some(edition_bump_seed);

    // metadata.serialize(&mut *metadata_account_info.data.borrow_mut())?;
    Ok(())
}
pub fn process_add_whiteList<'a>(
    program_id: &'a Pubkey,
    accounts: &'a [AccountInfo<'a>],
    activated: bool
) -> ProgramResult {
   //need an admin singer
   //white account address 
   let account_info_iter = &mut accounts.iter();
   //
   let payer_info = next_account_info(account_info_iter)?; // pay 
   assert_signer(payer_info)?;
   let mut is_admin = false;
   //
   let assert_payer = PROGRAM_ADMIN_PUBKEY.into_iter().any(|a|{a==&(payer_info.key.to_string().as_str())});
   if assert_payer{
    is_admin = true;
   }
   let creator_info = next_account_info(account_info_iter)?; //white wallet
   let whitelisted_creator_info = next_account_info(account_info_iter)?; //white account
   let rate_account = next_account_info(account_info_iter)?; //rate account 
   let receive_account = next_account_info(account_info_iter)?; //receive account
   let send_token_account =next_account_info(account_info_iter)?;
   let receive_token_account = next_account_info(account_info_iter)?;
   let system_program = next_account_info(account_info_iter)?;
   let token_program = next_account_info(account_info_iter)?;
   let rent_info = next_account_info(account_info_iter)?;
  
  
   if !whitelisted_creator_info.data_is_empty() {
       assert_owned_by(whitelisted_creator_info, program_id)?;
   }
  
   let creator_bump = assert_derivation(
       program_id,
       whitelisted_creator_info,
       &[
           WHITE_PREFIX.as_bytes(),
           program_id.as_ref(),
           creator_info.key.as_ref(),
       ],
   )?;
   let mut is_need_pay = false;
   if whitelisted_creator_info.data_is_empty() {
       is_need_pay = true;
       create_or_allocate_account_raw(
           *program_id,
           whitelisted_creator_info,
           rent_info,
           system_program,
           payer_info,
           WHITE_LIST_LENGTH,
           &[
               WHITE_PREFIX.as_bytes(),
               program_id.as_ref(),
               creator_info.key.as_ref(),
               &[creator_bump],
           ],
       )?;
   }
   if is_need_pay && !is_admin{ 
    
        let rate = Rate::from_account_info(rate_account)?;
        if rate.receive_pubkey != *receive_account.key {
            msg!(rate.receive_pubkey.to_string().as_str());
            return Err(ProgramError::InvalidAccountData);
        }
        let soc_pubkey = Pubkey::from_str(TOKEN_PUBKEY).unwrap();
        let soc_asoc_pubkey = get_associated_token_address(&payer_info.key,&soc_pubkey);
        if soc_asoc_pubkey != *send_token_account.key{
            return Err(ProgramError::InvalidAccountData); 
        }
        let soc_receive_asoc_pubkey = get_associated_token_address(&receive_account.key,&soc_pubkey);
        if soc_receive_asoc_pubkey != *receive_token_account.key{
            return Err(ProgramError::InvalidAccountData); 
        }
        msg!("transfer soc");
         
        let transfer_to_initializer_ix = spl_token::instruction::transfer(
            &token_program.key,
            &send_token_account.key,
            &receive_token_account.key,
            &payer_info.key,
            &[&payer_info.key],
            rate.creator_soc,
        )?;
        
        invoke(
            &transfer_to_initializer_ix,
            &[
                send_token_account.clone(),
                receive_token_account.clone(),
                payer_info.clone(),
                token_program.clone(),
            ],
        )?;
            // let receive_account_inner =  AccountMeta::new(rate.receive_pubkey, false);
        msg!("transfer sol");
        invoke(
            &system_instruction::transfer(&payer_info.key, &receive_account.key, rate.creator_sol),
            &[
                payer_info.clone(),
                receive_account.clone(),
                system_program.clone(),
            ],
        )?; 
   }
   let mut whitelisted_creator = WhitelistedCreator::from_account_info(whitelisted_creator_info)?;
   whitelisted_creator.key = Key::WhitelistedCreator;
   whitelisted_creator.address = *creator_info.key;
   whitelisted_creator.activated = activated;

   whitelisted_creator.serialize(&mut *whitelisted_creator_info.data.borrow_mut())?;
    Ok(())
}
pub fn process_remove_whiteList<'a>(
    program_id: &'a Pubkey,
    accounts: &'a [AccountInfo<'a>],
    white_pubkey: &'a Pubkey,
) -> ProgramResult {
    

    Ok(())
}
pub fn process_change_rate<'a>(
    program_id: &'a Pubkey,
    accounts: &'a [AccountInfo<'a>],
    rate_value: u8,
    creator_soc: u64,
    creator_sol: u64,
) -> ProgramResult {
    if rate_value >= 100{
        return Err(MetadataError::ArgsError.into());
    }
    let account_info_iter = &mut accounts.iter();
    //
    let payer_info = next_account_info(account_info_iter)?;
    //
    let assert_payer = PROGRAM_ADMIN_PUBKEY.into_iter().any(|a|{a== &(payer_info.key.to_string().as_str())});
    if !assert_payer{
        return Err(MetadataError::PowerError.into());
    }
    let receive_info = next_account_info(account_info_iter)?;
    let assert_receive = RECEIVE_PUBKEY.into_iter().any(|a|{a==&(receive_info.key.to_string().as_str())});
    if !assert_receive{
     return Err(MetadataError::PowerError.into());
    }
   assert_signer(payer_info)?;
    let rate_account_info = next_account_info(account_info_iter)?;
    let system_info = next_account_info(account_info_iter)?;
    let rent_info = next_account_info(account_info_iter)?;
    if !rate_account_info.data_is_empty() {
        assert_owned_by(rate_account_info, program_id)?;
    }
   
    let rate_bump = assert_derivation(
        program_id,
        rate_account_info,
        &[
            RATE_PREFIX.as_bytes(),
            program_id.as_ref(),
        ],
    )?;
 
    if rate_account_info.data_is_empty() {
        create_or_allocate_account_raw(
            *program_id,
            rate_account_info,
            rent_info,
            system_info,
            payer_info,
            RATE_LENGTH,
            &[
                RATE_PREFIX.as_bytes(),
                program_id.as_ref(),
                &[rate_bump],
            ],
        )?;
    }
    let mut rate = Rate::from_account_info(rate_account_info)?;
    rate.key = Key::Rate;
    rate.rate = rate_value; 
    rate.creator_soc = creator_soc;
    rate.creator_sol =  creator_sol;
    rate.receive_pubkey = *receive_info.key;
    rate.serialize(&mut *rate_account_info.data.borrow_mut())?;
     Ok(())
}
pub fn process_auction_sale<'a>(
    program_id: &'a Pubkey,
    accounts: &'a [AccountInfo<'a>],
    amount: u64,
    trade_type:u8,
    trade_key:Pubkey,
    // creator_num:u8,
) -> ProgramResult {
    msg!("invoke auction sale");
    let account_info_iter = &mut accounts.iter();
    //alice wallet
    let initializer = next_account_info(account_info_iter)?;

    if !initializer.is_signer {
        return Err(ProgramError::MissingRequiredSignature);
    }
    // let white_account_info = next_account_info(account_info_iter)?;
    // if !white_account_info.data_is_empty() {
    //     assert_owned_by(white_account_info, program_id)?;
    //     let  whitelisted_creator = WhitelistedCreator::from_account_info(white_account_info)?;
    //     if !whitelisted_creator.activated  || whitelisted_creator.address != * initializer.key {
    //         return return Err(MetadataError::WhiteListError.into());
    //     }
    // }else{
    //     return return Err(MetadataError::WhiteListError.into());
    // }
    //check args
    if(!(trade_type == 1  ||trade_type == 2)){
        return Err(MetadataError::ArgsError.into());
    }
    let native_token_key = Pubkey::from_str(NATIVE_TOKEN_PUBKEY).unwrap();
    let token_key = Pubkey::from_str(TOKEN_PUBKEY).unwrap();
    if (!(trade_key == native_token_key || trade_key == token_key)) {
        return Err(MetadataError::ArgsError.into());
    }

    msg!("check signer end");
    //临时存储X-token的账户
    let temp_token_account = next_account_info(account_info_iter)?;
    if *temp_token_account.owner != spl_token::id() {
        return Err(ProgramError::IncorrectProgramId);
    }
    msg!("check temp_token_account end ");
    //token address
    let token_address = next_account_info(account_info_iter)?;
    let token_account= next_account_info(account_info_iter)?;
    if *token_address.owner != spl_token::id() {
        return Err(ProgramError::IncorrectProgramId);
    }
   
    
     
    msg!("check token_address end ");
    //创建一个属于本合约的账户，存储交易信息
    let escrow_account = next_account_info(account_info_iter)?;
    if *escrow_account.owner != *program_id {
        return Err(ProgramError::IncorrectProgramId);
    }
    msg!("check escrow_account end ");
    let owner_account_info = next_account_info(account_info_iter)?;
    if *initializer.key != *owner_account_info.key {
        return Err(MetadataError::OwnerMismatch.into());
    }
    //payment type addr
    let pay_mint_addr = next_account_info(account_info_iter)?;
    if trade_key != *pay_mint_addr.key {
        return Err(MetadataError::OwnerMismatch.into());
    }
    //creator  list check
    let metaplex_pubkey = METAPLEX_PROGRAM_ID
    .parse::<Pubkey>()
    .expect("Failed to parse Metaplex Program Id");
    let seeds = &[
        PREFIX.as_bytes(),
        metaplex_pubkey.as_ref(),
        token_address.key.as_ref(),
    ];

    let (pda, _) = Pubkey::find_program_address(seeds, &metaplex_pubkey);
    if  *token_account.key != pda{
        return Err(ProgramError::IncorrectProgramId);
    }
    let metadata: Metadata =  Metadata::from_account_info(&token_account)?;
    match metadata.data.creators {
         Some(c)=>{
            let creator_count = c.len();
            msg!("account len:{}",creator_count);
            let mut white_creator = Vec::new();
            let mut verified_creator = Vec::new();
            for i in 0..creator_count{
                let white_creator_account =  next_account_info(account_info_iter)?;
                if !white_creator_account.data_is_empty(){
                    let white_creator_account_info = WhitelistedCreator::from_account_info(&white_creator_account)?;
                    // msg!(white_creator_account_info.address.to_string().as_str());
                    if white_creator_account_info.activated {
                        white_creator.push(white_creator_account_info.address);
                    }
                }
                let creator = &c[i];
                if creator.verified{
                    verified_creator.push(creator.address);
                }
            }
            let mut is_avalid = true;
            msg!("verified_ len account:{}",verified_creator.len());
            msg!("white len account:{}",white_creator.len());
            if verified_creator.len() >=creator_count  && white_creator.len()>=creator_count{
                for i in 0..creator_count{
                    if !verified_creator.contains(&white_creator[i]){
                        is_avalid = false;
                        break;
                    }
                }
            }else{
                is_avalid = false; 
            }
            if !is_avalid{
                return Err(MetadataError::WhiteListECheckrror.into());
            }
         },
         None=>print!("{}",1),
     }
    //creator list check end

    msg!("check owner_account_info end ");
    let rent = &Rent::from_account_info(next_account_info(account_info_iter)?)?;

    if !rent.is_exempt(escrow_account.lamports(), escrow_account.data_len()) {
        return Err(MetadataError::NotRentExempt.into());
    }
    msg!("check rent end ");
    let token_program = next_account_info(account_info_iter)?;
    
    let mut escrow_info = AuctionSale::from_account_info(escrow_account)?;
    if escrow_info.is_initialized() {
        return Err(ProgramError::AccountAlreadyInitialized);
    }
    msg!("check escrow_info end ");
    escrow_info.is_initialized = true;
    escrow_info.initializer_pubkey = *initializer.key;
    escrow_info.temp_token_account_pubkey = *temp_token_account.key;
    escrow_info.mint_key = *token_address.key;
    escrow_info.expected_amount = amount;
    escrow_info.key = Key::AuctionSale;
    escrow_info.trade_type = trade_type;
    escrow_info.trade_pubkey = trade_key;

    escrow_info.serialize(&mut *escrow_account.data.borrow_mut())?;
    // Escrow::pack(escrow_info, &mut escrow_account.try_borrow_mut_data()?)?;
    let (pda, _nonce) = Pubkey::find_program_address(&[b"auction"], program_id);
    //系统的token合约
  
    //把临时存储X-token的账户的拥有者改为pda
    let owner_change_ix = spl_token::instruction::set_authority(
        token_program.key,
        temp_token_account.key,
        Some(&pda),
        spl_token::instruction::AuthorityType::AccountOwner,
        initializer.key,
        &[&initializer.key],
    )?;

    msg!("Calling the token program to transfer token account ownership...");
    invoke(
        &owner_change_ix,
        &[
            temp_token_account.clone(),
            initializer.clone(),
            token_program.clone(),
        ],
    )?;

    Ok(())
}

fn process_auction_buy(
    accounts: &[AccountInfo],
    program_id: &Pubkey,
) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
    //bob的钱包
    let taker = next_account_info(account_info_iter)?;

    if !taker.is_signer {
        return Err(ProgramError::MissingRequiredSignature);
    }
    
    //bob的x-token地址
    let takers_token_to_receive_account = next_account_info(account_info_iter)?;
    //bob的y-token地址
    let takers_sending_token_account = next_account_info(account_info_iter)?;
    
    //存储alice的x-token的account
    let pdas_temp_token_account = next_account_info(account_info_iter)?;
    let pdas_temp_token_account_info =
        TokenAccount::unpack(&pdas_temp_token_account.try_borrow_data()?)?;
    let (pda, nonce) = Pubkey::find_program_address(&[b"auction"], program_id);

   // if amount_expected_by_taker != pdas_temp_token_account_info.amount {
     //   return Err(EscrowError::ExpectedAmountMismatch.into());
    //}
//  Alice的钱包
    let initializers_main_account = next_account_info(account_info_iter)?;
   //Alice接受y-token的地址
   let initializers_token_to_receive_account = next_account_info(account_info_iter)?;
   
    //交易信息
    let escrow_account = next_account_info(account_info_iter)?;

    let escrow_info = AuctionSale::from_account_info(escrow_account)?;
    if !escrow_info.is_initialized{
        return Err(MetadataError::Uninitialized.into());
    }
    
    if escrow_info.temp_token_account_pubkey != *pdas_temp_token_account.key {
        msg!("error mismatch1");
        return Err(ProgramError::InvalidAccountData);
    }

    if escrow_info.initializer_pubkey != *initializers_main_account.key {
        msg!("error mismatch2");
        return Err(ProgramError::InvalidAccountData);
    }

      
      //临时存储X-token的拥有者
    let pda_account = next_account_info(account_info_iter)?;
    // 
    let rate_account = next_account_info(account_info_iter)?;
    let receive_account = next_account_info(account_info_iter)?;

    let token_program = next_account_info(account_info_iter)?;
    let system_program = next_account_info(account_info_iter)?;
    let rate = Rate::from_account_info(rate_account)?;
    if (escrow_info.trade_type == 2){
        let soc_pubkey = Pubkey::from_str(TOKEN_PUBKEY).unwrap();
        let soc_asoc_pubkey = get_associated_token_address(&taker.key,&soc_pubkey);
        if soc_asoc_pubkey != *takers_sending_token_account.key{
            return Err(ProgramError::InvalidAccountData); 
        }
        let soc_receive_asoc_pubkey = get_associated_token_address(&initializers_main_account.key,&soc_pubkey);
        if soc_receive_asoc_pubkey != *initializers_token_to_receive_account.key{
            return Err(ProgramError::InvalidAccountData); 
        }
        msg!("transfer soc");
        msg!("transfer soc {}",escrow_info.expected_amount);
        msg!("transfer send soc {}",&takers_sending_token_account.key.to_string());
        msg!("transfer receive soc {}",&initializers_token_to_receive_account.key.to_string());
        let transfer_to_initializer_ix = spl_token::instruction::transfer(
            token_program.key,
            takers_sending_token_account.key,
            initializers_token_to_receive_account.key,
            taker.key,
            &[&taker.key],
            escrow_info.expected_amount,
        )?;

        invoke(
            &transfer_to_initializer_ix,
            &[
                takers_sending_token_account.clone(),
                initializers_token_to_receive_account.clone(),
                taker.clone(),
                token_program.clone(),
            ],
        )?;
    }else{
        if rate.receive_pubkey != *receive_account.key {
            msg!(rate.receive_pubkey.to_string().as_str());
            return Err(ProgramError::InvalidAccountData);
        }
        let fee = escrow_info.expected_amount * rate.rate as u64 /100;
        let income =  escrow_info.expected_amount - fee;
        if fee >0 {
            // let receive_account_inner =  AccountMeta::new(rate.receive_pubkey, false);
            invoke(
                &system_instruction::transfer(&taker.key, &rate.receive_pubkey, fee),
                &[
                    taker.clone(),
                    receive_account.clone(),
                    system_program.clone(),
                ],
            )?; 
        }
        invoke(
            &system_instruction::transfer(&taker.key, &escrow_info.initializer_pubkey, income),
            &[
                taker.clone(),
                initializers_main_account.clone(),
                system_program.clone(),
            ],
        )?;
    }
    msg!("spl_token::instruction::transfer");
    let transfer_to_taker_ix = spl_token::instruction::transfer(
        token_program.key,
        pdas_temp_token_account.key,
        takers_token_to_receive_account.key,
        &pda,
        &[&pda],
        pdas_temp_token_account_info.amount,
    )?;
    msg!("Calling the token program to transfer tokens to the taker...");
    invoke_signed(
        &transfer_to_taker_ix,
        &[
            pdas_temp_token_account.clone(),
            takers_token_to_receive_account.clone(),
            pda_account.clone(),
            token_program.clone(),
        ],
        &[&[&b"auction"[..], &[nonce]]],
    )?;
    msg!("spl_token::instruction::close_account");
    let close_pdas_temp_acc_ix = spl_token::instruction::close_account(
        token_program.key,
        pdas_temp_token_account.key,
        initializers_main_account.key,
        &pda,
        &[&pda],
    )?;
    msg!("Calling the token program to close pda's temp account...");
    invoke_signed(
        &close_pdas_temp_acc_ix,
        &[
            pdas_temp_token_account.clone(),
            initializers_main_account.clone(),
            pda_account.clone(),
            token_program.clone(),
        ],
        &[&[&b"auction"[..], &[nonce]]],
    )?;

    msg!("Closing the escrow account...");
    **initializers_main_account.try_borrow_mut_lamports()? = initializers_main_account
        .lamports()
        .checked_add(escrow_account.lamports())
        .ok_or(MetadataError::AmountOverflow)?;
    **escrow_account.try_borrow_mut_lamports()? = 0;
    *escrow_account.try_borrow_mut_data()? = &mut [];
    Ok(())
}
fn process_auction_cancel(
    accounts: &[AccountInfo],
    program_id: &Pubkey,
) -> ProgramResult {
    let account_info_iter = &mut accounts.iter();
   //bob的钱包
   let taker = next_account_info(account_info_iter)?;

   if !taker.is_signer {
       return Err(ProgramError::MissingRequiredSignature);
   }
   //bob的y-token地址
   //let takers_sending_token_account = next_account_info(account_info_iter)?;
   //bob的x-token地址
   let takers_token_to_receive_account = next_account_info(account_info_iter)?;
   //存储alice的x-token的account
   let pdas_temp_token_account = next_account_info(account_info_iter)?;
   let pdas_temp_token_account_info =
       TokenAccount::unpack(&pdas_temp_token_account.try_borrow_data()?)?;
   let (pda, nonce) = Pubkey::find_program_address(&[b"auction"], program_id);

  // if amount_expected_by_taker != pdas_temp_token_account_info.amount {
    //   return Err(EscrowError::ExpectedAmountMismatch.into());
   //}
//  Alice的钱包
   let initializers_main_account = next_account_info(account_info_iter)?;
  //Alice接受y-token的地址
 //  let initializers_token_to_receive_account = next_account_info(account_info_iter)?;
   //交易信息
   let escrow_account = next_account_info(account_info_iter)?;

   let escrow_info = AuctionSale::from_account_info(escrow_account)?;
   if !escrow_info.is_initialized{
       return Err(MetadataError::Uninitialized.into());
   }
   
   if escrow_info.temp_token_account_pubkey != *pdas_temp_token_account.key {
       msg!("error mismatch1");
       return Err(ProgramError::InvalidAccountData);
   }

   if escrow_info.initializer_pubkey != *initializers_main_account.key {
       msg!("error mismatch2");
       return Err(ProgramError::InvalidAccountData);
   }
   if escrow_info.initializer_pubkey != *taker.key {
    msg!("error mismatch2");
    return Err(ProgramError::InvalidAccountData);
}

  // if escrow_info.initializer_token_to_receive_account_pubkey
    //   != *initializers_token_to_receive_account.key
   //{
     //  return Err(ProgramError::InvalidAccountData);
   //}
     //临时存储X-token的拥有者
     let pda_account = next_account_info(account_info_iter)?;

   let token_program = next_account_info(account_info_iter)?;
//    let system_program = next_account_info(account_info_iter)?;
//    invoke(
//        &system_instruction::transfer(&taker.key, &escrow_info.initializer_pubkey, escrow_info.expected_amount),
//        &[
//            taker.clone(),
//            initializers_main_account.clone(),
//            system_program.clone(),
//        ],
//    )?;
 
   msg!("spl_token::instruction::transfer");
   let transfer_to_taker_ix = spl_token::instruction::transfer(
       token_program.key,
       pdas_temp_token_account.key,
       takers_token_to_receive_account.key,
       &pda,
       &[&pda],
       pdas_temp_token_account_info.amount,
   )?;
   msg!("Calling the token program to transfer tokens to the taker...");
   invoke_signed(
       &transfer_to_taker_ix,
       &[
           pdas_temp_token_account.clone(),
           takers_token_to_receive_account.clone(),
           pda_account.clone(),
           token_program.clone(),
       ],
       &[&[&b"auction"[..], &[nonce]]],
   )?;
   msg!("spl_token::instruction::close_account");
   let close_pdas_temp_acc_ix = spl_token::instruction::close_account(
       token_program.key,
       pdas_temp_token_account.key,
       initializers_main_account.key,
       &pda,
       &[&pda],
   )?;
   msg!("Calling the token program to close pda's temp account...");
   invoke_signed(
       &close_pdas_temp_acc_ix,
       &[
           pdas_temp_token_account.clone(),
           initializers_main_account.clone(),
           pda_account.clone(),
           token_program.clone(),
       ],
       &[&[&b"auction"[..], &[nonce]]],
   )?;

   msg!("Closing the escrow account...");
   **initializers_main_account.try_borrow_mut_lamports()? = initializers_main_account
       .lamports()
       .checked_add(escrow_account.lamports())
       .ok_or(MetadataError::AmountOverflow)?;
   **escrow_account.try_borrow_mut_lamports()? = 0;
   *escrow_account.try_borrow_mut_data()? = &mut [];
   Ok(())
}